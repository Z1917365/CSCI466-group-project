<?php
  // Unsafe. Yay.
  $username = "z1838505";
  $password = "1997May27";
?>